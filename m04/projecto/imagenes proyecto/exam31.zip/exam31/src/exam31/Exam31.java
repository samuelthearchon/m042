/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exam31;

import java.util.Scanner;

/**
 *
 * @author sash1062
 */
public class Exam31 {

    private static double dineroTotal;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    double dineroIntroducido = 0; 
            
    while(true){
        mostrarMenuPrincipal(); // aqui hago el menu
        int opcionPrincipal = leerEntero(scanner);
        
       switch(opcionPrincipal){ // para la opciones utilizo el switch
         case 1:
          dineroIntroducido += seleccionarProducto("Refrescos", scanner);
          break;
         case 2:
          dineroIntroducido += seleccionarProducto("Café", scanner);
          break;
         case 3:
          dineroIntroducido += seleccionarProducto("Snacks", scanner);
           break;
          case 4:
          System.out.println("Gracias por usar la máquina expendedora. Hasta luego.");

          System.out.println("Gracias por usar la máquina expendedora. Hasta luego.");
           return;
           default:
           System.out.println("Opción no válida. Introduce una opción válida.");
            break;
                     }
        }
    }


    public static void mostrarMenuPrincipal() {
        System.out.println("MENÚ PRINCIPAL:");  //creo las opciones y las imprimo con south
        System.out.println("1. REFRESCOS");
        System.out.println("2. CAFÉ");
        System.out.println("3. SNACKS");
        System.out.println("4. SORTIR");
        System.out.print("Escull una opció: ");
    }

  
    public static double seleccionarProducto(String categoria, Scanner scanner) {
        double precioTotal = 0;

        while (true) {
            System.out.println("MENÚ " + categoria.toUpperCase() + ":"); // aqui se hacen los precios
            System.out.println("1. Agua - 2€");
            System.out.println("2. CocaCola - 6€");
            System.out.println("3. Fanta - 5€");
            System.out.println("4. Monster - 8€");
            System.out.println("5. RedBull - 7€");
            System.out.println("6. SORTIR");
            System.out.print("Escull una opció: ");
            
            int opcionProducto = leerEntero(scanner);
            
            if(opcionProducto >= 1 && opcionProducto <5){
               double precioProducto = obtenerPrecioProducto(opcionProducto);
               System.out.println("El precio es:" + precioProducto +"€");
                             double dineroFaltante = precioProducto - precioTotal;

                if (dineroFaltante > 0) {
                    System.out.println("Introduce " + dineroFaltante + "€: ");
                    double dineroIntroducido = leerDinero(scanner);
                    dineroTotal += dineroIntroducido;

                    if (dineroTotal < precioProducto) {
                        System.out.println("Dinero insuficiente. Introduce más dinero.");
                    } else {
                        precioTotal += precioProducto;
                        double cambio = dineroTotal - precioTotal;
                        if (cambio > 0) {
                            System.out.println("Gracias por su compra. Su cambio es de " + cambio + "€.");
                        } else {
                            System.out.println("Gracias por su compra.");
                        }
                        break;
                    }
                } else {
                    System.out.println("Gracias por su compra.");
                    break;
                }
            }else if (opcionProducto ==6){
             System.out.println("Opción no válida. Introduce una opción válida.");
             
           }
        }
return precioTotal;
    }
  
    
    public static double obtenerPrecioProducto(int opcion) {  //aqui hacemos los calculos para obtener los calculos de los productos
        switch (opcion) {
            case 1:
                return 2.0;
            case 2:
                return 6.0;
            case 3:
                return 5.0;
            case 4:
                return 8.0;
            case 5:
                return 7.0;
            default:
                return 0.0;
        }
    }


    
public static int leerEntero(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.println("Introduce un número entero válido.");
            scanner.next();
        }
        return scanner.nextInt();
    }

    public static double leerDinero(Scanner scanner) {
        while (!scanner.hasNextDouble()) {
            System.out.println("Introduce una cantidad válida en euros.");
            scanner.next();
        }
        return scanner.nextDouble();
    }
}

          
     

          


         
   